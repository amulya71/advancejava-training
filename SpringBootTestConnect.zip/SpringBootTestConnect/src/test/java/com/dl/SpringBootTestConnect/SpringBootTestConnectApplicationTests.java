package com.dl.SpringBootTestConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTestConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
